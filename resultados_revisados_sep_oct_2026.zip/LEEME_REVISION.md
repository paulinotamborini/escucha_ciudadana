# Escucha ciudadana — septiembre y octubre de 2026

## Versión revisada

Usar `dataset_escucha_ciudadana_metabase.csv` de este paquete para las siguientes pruebas del tablero. No sobrescribe el archivo original de Colab. Los registros corresponden al 01/09/2026 al 25/10/2026 inclusive; octubre es parcial.

| Fuente | Registros conservados | Evaluables para sentimiento | Cobertura |
|---|---:|---:|---:|
| Social público | 10.743 | 8.934 | 83,16 % |
| Encuesta | 7.571 | 6.183 | 81,67 % |
| Conversación privada | 299.011 | 181.829 | 60,81 % |
| Total de registros de las tres fuentes | 317.325 | 196.946 | No usar como opinión global representativa |

Las unidades son registros: mensajes privados, actividades públicas y respuestas con comentario. No son personas ni conversaciones únicas. El universo privado sigue los filtros de la extracción: texto con al menos una letra, excluyendo spam, borrados, cuentas de prueba y marcadores de adjuntos.

## Corrección realizada

Se encontraron 577 registros públicos cuyo texto es una referencia interna `aws_s3:...`. El modelo los había considerado neutros. Se conservaron como eventos, pero quedaron como **No analizable**, con tipo **Referencia interna de adjunto**, excluidos de sentimiento y temática. No se volvió a ejecutar el modelo y no se modificaron los demás registros.

El número total público incluye esos eventos: titular una tarjeta de 10.743 como **Registros públicos**, no como 10.743 opiniones ni comentarios textuales evaluados. La tarjeta de sentimiento debe usar como denominador los 8.934 evaluables, e incluir por separado la categoría **Incierto**. Si se usa un denominador diferente, indicarlo expresamente.

## Sin ponderaciones

Cada registro cuenta una vez. `sample_weight=1`, `weighted_records=1`, `is_sample=False`. Las columnas de pesos existen solo por compatibilidad. Para las visualizaciones nuevas usar conteos reales, con las fuentes separadas.

## Validación e interpretación pendientes

- `muestra_validacion_manual_refinada.csv` contiene 420 registros para revisar. Las columnas de revisión humana están vacías. Los controles técnicos no demuestran la precisión del modelo.
- Revisar especialmente sarcasmo, respuestas muy breves y cortesías operativas. No toda frase positiva equivale a satisfacción con MuniBot, ni todo reclamo describe tono emocional negativo.
- `theme_origin=Contexto/tags` identifica el servicio asociado al caso. No demuestra que el comentario mencione o evalúe ese servicio. Por ejemplo, una crítica a las opciones del bot puede estar asociada por etiquetas a Alumbrado. Mantener visible esta diferencia.
- En público, las temáticas se identifican exclusivamente desde el texto. Solo 2.836 registros tienen temática identificada; no son todos los comentarios. No se ejecutó descubrimiento de clusters.
- Encuestas: la fecha es `sent_at`, correspondiente al envío de la encuesta, no necesariamente al momento de respuesta.
- La anonimización automática es básica. Los controles de correos y números largos no certifican la eliminación de nombres o direcciones. Mantener acceso restringido.
- No comparar septiembre y octubre como meses completos ni mezclar estos conteos con la muestra ponderada antigua. Si se publica evolución mensual, señalar octubre parcial hasta el día 25.

## Archivos de control

- `auditoria_tecnica.json`: cobertura, IDs, fechas, pesos unitarios, probabilidades y distribuciones comprobadas.
- `metadata_correccion.json`: trazabilidad del archivo original y los 577 cambios.
- `resumen_dataset_metabase.csv`: recuentos y cobertura actualizados.
- `resumen_tono_sin_ponderacion.csv`: distribución de tono con denominador de registros evaluables, incluyendo inciertos.

La app y el dataset publicado de Metabase no se modificaron en esta revisión. Antes de reemplazarlos, validar la muestra y comprobar títulos, filtros y denominadores.
